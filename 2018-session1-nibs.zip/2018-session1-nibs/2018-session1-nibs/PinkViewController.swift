//
//  PinkViewController.swift
//  2018-session1-nibs
//
//  Created by T. Andrew Binkowski on 4/1/18.
//  Copyright © 2018 T. Andrew Binkowski. All rights reserved.
//

import UIKit

class PinkViewController: ViewController {
  
  @IBAction func tapDismiss(_ sender: UIButton) {
    self.dismiss(animated: true, completion: nil)
    
    // Pop a VC programatically
    //self.navigationController?.popViewController(animated: true)
    }
    
}
